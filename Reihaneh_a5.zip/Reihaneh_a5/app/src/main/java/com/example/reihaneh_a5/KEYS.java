package com.example.reihaneh_a5;

public enum KEYS {
    RESTOURENT_LIST
}
